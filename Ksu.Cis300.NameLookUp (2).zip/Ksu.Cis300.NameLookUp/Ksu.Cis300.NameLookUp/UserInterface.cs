﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Ksu.Cis300.NameLookUp
{
    public partial class UserInterface : Form
    {
        private LinkedListArray[] _namesLists = null;
        public UserInterface()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void UxLoadFile_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    LinkedListArray listArray = new LinkedListArray();
                    listArray.LoadFile(openFileDialog1.FileName);
                    /**/
                }
                catch (Exception ex)
                {
                    throw new System.Exception("User did not select a proper file" + ex);
                }
            }
        }

        private void UxSaveResults_Click(object sender, EventArgs e)
        {

        }
    }
    }
}

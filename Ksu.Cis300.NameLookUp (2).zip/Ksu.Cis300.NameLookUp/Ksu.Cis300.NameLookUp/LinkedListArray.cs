﻿using Ksu.Cis300.NameLookup;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Ksu.Cis300.NameLookUp
{
    public class LinkedListArray
    {
        LinkedListCell<NameInformation>[] _lists = new LinkedListCell<NameInformation>[26];

        public LinkedListCell<NameInformation> FindFirstCell(string namePrefix)
        {
            LinkedListCell<NameInformation> first = _lists[namePrefix[0] - 'A']; ///almost done
            if (first != null)
            {
                return first;
            }
            else return null;
        }

        public LinkedListCell<NameInformation> InsertNameInformation(NameInformation info, LinkedListCell<NameInformation> cell)
        {
            string name = info.Name;
            LinkedListCell<NameInformation> tempCell = FindFirstCell(name);
            int comparison = cell.Data.Name.CompareTo(name);
            if (cell == null)
            {
                cell.Data = info;
                return cell;
            }
            else if (comparison >= 0) ///might be backward
            {
                LinkedListCell<NameInformation> moveOverCell = new LinkedListCell<NameInformation>();
                moveOverCell.Next = cell;
                moveOverCell.Data = info;
                cell = moveOverCell;
                return cell;
            }
            else
            {
                LinkedListCell<NameInformation> inBetweenCell = new LinkedListCell<NameInformation>();
                inBetweenCell = cell;
                inBetweenCell.Data = info;
                while (inBetweenCell.Next != null)
                {
                    int compare = cell.Data.Name.CompareTo(name);
                    if (compare > 0)
                    {
                        inBetweenCell = inBetweenCell.Next;
                    }
                    else
                    {

                    }
                }
               

            }
        }

        public void LoadFile(string filename)
        {
            LinkedListCell<NameInformation>[] tempList = _lists;
           try
            {
                using (StreamReader sr = new StreamReader(filename))
                {
                    while (!sr.EndOfStream)
                    {
                        string[] splitLine = sr.ReadLine().Split('\t');
                        string name = splitLine[0];
                        float frequency = float.Parse(splitLine[1]);
                        float cumulativeFrequency = float.Parse(splitLine[2]);
                        int rank = Convert.ToInt32(splitLine[3]);
                        NameInformation newInfo = new NameInformation(name, frequency, rank, cumulativeFrequency);
                        LinkedListCell<NameInformation> newFileInfo = InsertNameInformation(newInfo, FindFirstCell(newInfo.Name));
                        tempList[name[0] - 'A'] = newFileInfo;
                    }
                    _lists = tempList;
                }
            }
           catch (Exception ex)
            {
                throw new System.Exception("Error reading file, no information was changed." + ex);
            }
        }
    }
}
